
CyberSkill Academy - Static Demo (Prototype)
-------------------------------------------

This is a simple static demo (dark-mode) showing how the app will look.
It uses mock payment flows (JazzCash / EasyPaisa placeholders) and placeholder lesson pages.

Files:
- index.html
- styles.css

How to host quickly (Netlify - drag & drop):
1. Download the ZIP and extract.
2. Go to https://app.netlify.com/drop
3. Drag the extracted folder (or the .zip) to Netlify drop area.
4. Netlify will publish a live link in seconds.

Note: This is a demo. For a full React app + backend + real payments we will replace this with the production build.
